﻿Imports System.IO
Imports System.Net
Imports System.Xml
Imports Newtonsoft.Json.Linq

Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim f1 As FileStream = New FileStream("c:/aula/teste.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite)

        Dim nome As String
        nome = "Meu primeiro arquivo txt...."

        Dim i As Integer
        For i = 0 To 20
            f1.WriteByte(CByte(i))
            f1.WriteByte(CByte(i))
        Next i
        f1.Position = 0
        For i = 0 To 20
            Debug.WriteLine("{0} ", f1.ReadByte())
        Next i
        f1.Close()

        FuncaoJSON()

    End Sub

    Private Sub FuncaoXML()
        Dim doc As New XmlDocument
        doc.Load("https://www.w3schools.com/xml/note.xml")
        Dim nodes As XmlNodeList = doc.SelectNodes("note")
        Dim query = nodes.Cast(Of XmlNode).Select(Function(x)
                                                      Return New With
                                                      {
                                                      .To = x.SelectSingleNode("to").InnerText,
                                                      .From = x.SelectSingleNode("from").InnerText,
                                                      .heading = x.SelectSingleNode("heading").InnerText,
                                                      .body = x.SelectSingleNode("body").InnerText
                                                      }
                                                  End Function).FirstOrDefault
        If query IsNot Nothing Then
            MessageBox.Show(String.Format("{0}{1}{2}{1}{3}{1}{4}", query.To, "", query.From, query.heading, query.body))
        Else
            MessageBox.Show("nao encontrou nada")
        End If
    End Sub

    Private Sub FuncaoJSON()

        Dim request As HttpWebRequest
        Dim response As HttpWebResponse = Nothing
        Dim reader As StreamReader
        request = DirectCast(WebRequest.Create("http://time.jsontest.com/"), HttpWebRequest)
        response = DirectCast(request.GetResponse(), HttpWebResponse)
        reader = New StreamReader(response.GetResponseStream())

        Dim rawresp As String
        rawresp = reader.ReadToEnd()

        Dim jResults As Object = JObject.Parse(rawresp)

        If (jResults("time")) IsNot Nothing Then
            MessageBox.Show(jResults("time"))
        End If
    End Sub

End Class
