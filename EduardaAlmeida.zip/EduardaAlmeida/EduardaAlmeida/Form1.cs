﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EduardaAlmeida
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btExecute_Click(object sender, EventArgs e)
        {
            string texto1 = textParam1.Text;
            string texto2 = textParam2.Text;
            ClassMetodo metodo = new ClassMetodo();
            listBox1.Items.Add(metodo.concatenar(texto1, texto2));
        }
    }
}
