﻿namespace EduardaAlmeida
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textParam1 = new System.Windows.Forms.TextBox();
            this.textParam2 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btExecute = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(83, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Parametro1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(83, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Parametro2:";
            // 
            // textParam1
            // 
            this.textParam1.Location = new System.Drawing.Point(170, 44);
            this.textParam1.Name = "textParam1";
            this.textParam1.Size = new System.Drawing.Size(244, 20);
            this.textParam1.TabIndex = 2;
            // 
            // textParam2
            // 
            this.textParam2.Location = new System.Drawing.Point(170, 89);
            this.textParam2.Name = "textParam2";
            this.textParam2.Size = new System.Drawing.Size(244, 20);
            this.textParam2.TabIndex = 3;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(86, 146);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(234, 212);
            this.listBox1.TabIndex = 4;
            // 
            // btExecute
            // 
            this.btExecute.Location = new System.Drawing.Point(129, 378);
            this.btExecute.Name = "btExecute";
            this.btExecute.Size = new System.Drawing.Size(136, 23);
            this.btExecute.TabIndex = 5;
            this.btExecute.Text = "CLIQUE AQUI!";
            this.btExecute.UseVisualStyleBackColor = true;
            this.btExecute.Click += new System.EventHandler(this.btExecute_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::EduardaAlmeida.Properties.Resources.a14c5408_7b7e_4d8f_ab2b_170b646c64cf;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btExecute);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textParam2);
            this.Controls.Add(this.textParam1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textParam1;
        private System.Windows.Forms.TextBox textParam2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btExecute;
    }
}

