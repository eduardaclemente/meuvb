﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EduardaAlmeida
{
    internal class ClassMetodo
    {
        public string concatenar(string Param1, string Param2)
        {
            return Param1 + " " + Param2;
        }
    }
}
