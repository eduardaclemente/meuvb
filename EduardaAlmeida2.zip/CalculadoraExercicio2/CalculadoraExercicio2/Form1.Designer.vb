﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.textBoxDescr = New System.Windows.Forms.TextBox()
        Me.textBoxN1 = New System.Windows.Forms.TextBox()
        Me.textBoxN2 = New System.Windows.Forms.TextBox()
        Me.textBoxSoma = New System.Windows.Forms.TextBox()
        Me.buttonAdicao = New System.Windows.Forms.Button()
        Me.buttonSubtracao = New System.Windows.Forms.Button()
        Me.buttonDivisao = New System.Windows.Forms.Button()
        Me.buttonMultiplicar = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.buttonAdd = New System.Windows.Forms.Button()
        Me.buttonRemove = New System.Windows.Forms.Button()
        Me.buttonClean = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(60, 62)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Descrição:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(60, 120)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(27, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "N°1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(60, 182)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(27, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "N°2"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(60, 251)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Soma:"
        '
        'textBoxDescr
        '
        Me.textBoxDescr.Location = New System.Drawing.Point(127, 59)
        Me.textBoxDescr.Name = "textBoxDescr"
        Me.textBoxDescr.Size = New System.Drawing.Size(176, 23)
        Me.textBoxDescr.TabIndex = 4
        '
        'textBoxN1
        '
        Me.textBoxN1.Location = New System.Drawing.Point(127, 117)
        Me.textBoxN1.Name = "textBoxN1"
        Me.textBoxN1.Size = New System.Drawing.Size(176, 23)
        Me.textBoxN1.TabIndex = 5
        '
        'textBoxN2
        '
        Me.textBoxN2.Location = New System.Drawing.Point(127, 179)
        Me.textBoxN2.Name = "textBoxN2"
        Me.textBoxN2.Size = New System.Drawing.Size(176, 23)
        Me.textBoxN2.TabIndex = 6
        '
        'textBoxSoma
        '
        Me.textBoxSoma.Location = New System.Drawing.Point(127, 244)
        Me.textBoxSoma.Name = "textBoxSoma"
        Me.textBoxSoma.Size = New System.Drawing.Size(176, 23)
        Me.textBoxSoma.TabIndex = 7
        '
        'buttonAdicao
        '
        Me.buttonAdicao.Location = New System.Drawing.Point(60, 302)
        Me.buttonAdicao.Name = "buttonAdicao"
        Me.buttonAdicao.Size = New System.Drawing.Size(121, 40)
        Me.buttonAdicao.TabIndex = 8
        Me.buttonAdicao.Text = "ADIÇÃO"
        Me.buttonAdicao.UseVisualStyleBackColor = True
        '
        'buttonSubtracao
        '
        Me.buttonSubtracao.Location = New System.Drawing.Point(216, 302)
        Me.buttonSubtracao.Name = "buttonSubtracao"
        Me.buttonSubtracao.Size = New System.Drawing.Size(121, 40)
        Me.buttonSubtracao.TabIndex = 9
        Me.buttonSubtracao.Text = "SUBTRAÇÃO"
        Me.buttonSubtracao.UseVisualStyleBackColor = True
        '
        'buttonDivisao
        '
        Me.buttonDivisao.Location = New System.Drawing.Point(60, 361)
        Me.buttonDivisao.Name = "buttonDivisao"
        Me.buttonDivisao.Size = New System.Drawing.Size(121, 40)
        Me.buttonDivisao.TabIndex = 10
        Me.buttonDivisao.Text = "DIVISÃO"
        Me.buttonDivisao.UseVisualStyleBackColor = True
        '
        'buttonMultiplicar
        '
        Me.buttonMultiplicar.Location = New System.Drawing.Point(216, 361)
        Me.buttonMultiplicar.Name = "buttonMultiplicar"
        Me.buttonMultiplicar.Size = New System.Drawing.Size(121, 40)
        Me.buttonMultiplicar.TabIndex = 11
        Me.buttonMultiplicar.Text = "MULTIPLICAÇÃO"
        Me.buttonMultiplicar.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 15
        Me.ListBox1.Location = New System.Drawing.Point(415, 38)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(197, 259)
        Me.ListBox1.TabIndex = 12
        '
        'buttonAdd
        '
        Me.buttonAdd.Location = New System.Drawing.Point(646, 44)
        Me.buttonAdd.Name = "buttonAdd"
        Me.buttonAdd.Size = New System.Drawing.Size(100, 33)
        Me.buttonAdd.TabIndex = 13
        Me.buttonAdd.Text = "ADICIONAR"
        Me.buttonAdd.UseVisualStyleBackColor = True
        '
        'buttonRemove
        '
        Me.buttonRemove.Location = New System.Drawing.Point(646, 148)
        Me.buttonRemove.Name = "buttonRemove"
        Me.buttonRemove.Size = New System.Drawing.Size(100, 33)
        Me.buttonRemove.TabIndex = 14
        Me.buttonRemove.Text = "REMOVER"
        Me.buttonRemove.UseVisualStyleBackColor = True
        '
        'buttonClean
        '
        Me.buttonClean.Location = New System.Drawing.Point(646, 244)
        Me.buttonClean.Name = "buttonClean"
        Me.buttonClean.Size = New System.Drawing.Size(100, 33)
        Me.buttonClean.TabIndex = 15
        Me.buttonClean.Text = "LIMPAR"
        Me.buttonClean.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.CalculadoraExercicio2.My.Resources.Resources.one_piece_luffy_gear
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.buttonClean)
        Me.Controls.Add(Me.buttonRemove)
        Me.Controls.Add(Me.buttonAdd)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.buttonMultiplicar)
        Me.Controls.Add(Me.buttonDivisao)
        Me.Controls.Add(Me.buttonSubtracao)
        Me.Controls.Add(Me.buttonAdicao)
        Me.Controls.Add(Me.textBoxSoma)
        Me.Controls.Add(Me.textBoxN2)
        Me.Controls.Add(Me.textBoxN1)
        Me.Controls.Add(Me.textBoxDescr)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents textBoxDescr As TextBox
    Friend WithEvents textBoxN1 As TextBox
    Friend WithEvents textBoxN2 As TextBox
    Friend WithEvents textBoxSoma As TextBox
    Friend WithEvents buttonAdicao As Button
    Friend WithEvents buttonSubtracao As Button
    Friend WithEvents buttonDivisao As Button
    Friend WithEvents buttonMultiplicar As Button
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents buttonAdd As Button
    Friend WithEvents buttonRemove As Button
    Friend WithEvents buttonClean As Button
End Class
