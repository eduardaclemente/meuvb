﻿Public Class Form1
    Private Sub buttonAdicao_Click(sender As Object, e As EventArgs) Handles buttonAdicao.Click

        Dim var1 As Integer
        Dim var2 As Integer


        var1 = textBoxN1.Text
        var2 = textBoxN2.Text


        textBoxSoma.Text = var2 + var1


        Dim eduardaAlmeidaUtil As New EduardaAlmeidaUtil()

        eduardaAlmeidaUtil.Soma(var1, var2)


    End Sub

    Private Sub buttonSubtracao_Click(sender As Object, e As EventArgs) Handles buttonSubtracao.Click

        Dim var1 As Integer
        Dim var2 As Integer


        var1 = textBoxN1.Text
        var2 = textBoxN2.Text

        textBoxSoma.Text = var2 - var1

        Dim eduardaClementeUtil As New EduardaAlmeidaUtil()

        eduardaClementeUtil.Subtracao(var1, var2)

    End Sub

    Private Sub buttonDivisao_Click(sender As Object, e As EventArgs) Handles buttonDivisao.Click
        Dim var1 As Integer
        Dim var2 As Integer


        var1 = textBoxN1.Text
        var2 = textBoxN2.Text

        textBoxSoma.Text = var2 / var1

        Dim eduardaClementeUtil As New EduardaAlmeidaUtil()

        eduardaClementeUtil.Divisao(var1, var2)
    End Sub

    Private Sub buttonMultiplicar_Click(sender As Object, e As EventArgs) Handles buttonMultiplicar.Click
        Dim var1 As Integer
        Dim var2 As Integer


        var1 = textBoxN1.Text
        var2 = textBoxN2.Text

        textBoxSoma.Text = var2 / var1

        Dim eduardaClementeUtil As New EduardaAlmeidaUtil()

        eduardaClementeUtil.Multiplicao(var1, var2)
    End Sub

    Private Sub buttonAdd_Click(sender As Object, e As EventArgs) Handles buttonAdd.Click
        ListBox1.Items.Add(textBoxDescr.Text & " : " & textBoxSoma.Text)
    End Sub

    Private Sub buttonRemove_Click(sender As Object, e As EventArgs) Handles buttonRemove.Click
        ListBox1.Items.Remove(ListBox1.SelectedItem)
    End Sub

    Private Sub buttonClean_Click(sender As Object, e As EventArgs) Handles buttonClean.Click
        ListBox1.Items.Clear()
    End Sub
End Class
