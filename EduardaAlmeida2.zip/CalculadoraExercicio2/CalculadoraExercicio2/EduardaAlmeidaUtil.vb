﻿Public Class EduardaAlmeidaUtil

    Public Function Soma(var1 As Integer, var2 As Integer) As String
        Dim total As Integer

        total = var1 + var2

        Return "Sucesso"

    End Function
    Public Function Subtracao(var1 As Integer, var2 As Integer) As String
        Dim total As Integer

        total = var1 - var2

        Return "Sucesso"

    End Function
    Public Function Multiplicao(var1 As Integer, var2 As Integer) As String
        Dim total As Integer

        total = var1 * var2

        Return "Sucesso"

    End Function
    Public Function Divisao(var1 As Integer, var2 As Integer) As String
        Dim total As Integer

        total = var1 / var2

        Return "Sucesso"

    End Function

End Class
