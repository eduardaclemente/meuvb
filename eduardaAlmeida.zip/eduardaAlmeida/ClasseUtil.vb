﻿Public Class ClasseUtil
    'Public Function nomeSobrenome(Nome As String, Sobrenome As String) As String

    '    Return "Seu nome é " & Nome & " " & Sobrenome

    'End Function
    Public Function nomeSobrenome() As String

        Return "Eduarda Almeida"

    End Function


    Public Function validadorIdade(idade As Integer) As String
        If (idade < 18) Then

            MessageBox.Show(" Você tem menos de 18 anos")
            Return "sucesso "

        Else

            MessageBox.Show(" Você tem mais de 18 anos ")
            Return "sucesso "

        End If

    End Function

End Class
