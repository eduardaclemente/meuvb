﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SegundaTela
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SegundaTela))
        Me.ListBoxSegundaTela = New System.Windows.Forms.ListBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ListBoxSegundaTela
        '
        Me.ListBoxSegundaTela.FormattingEnabled = True
        Me.ListBoxSegundaTela.ItemHeight = 15
        Me.ListBoxSegundaTela.Location = New System.Drawing.Point(37, 21)
        Me.ListBoxSegundaTela.Name = "ListBoxSegundaTela"
        Me.ListBoxSegundaTela.Size = New System.Drawing.Size(253, 289)
        Me.ListBoxSegundaTela.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Violet
        Me.Button1.Location = New System.Drawing.Point(306, 287)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(185, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "ADICIONAR"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Violet
        Me.Button2.Location = New System.Drawing.Point(306, 258)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(183, 23)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "EXCLUIR"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'SegundaTela
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(669, 351)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ListBoxSegundaTela)
        Me.Name = "SegundaTela"
        Me.Text = "SegundaTela"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ListBoxSegundaTela As ListBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
