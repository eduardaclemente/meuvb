﻿Public Class SegundaTela
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim Form1 As New Form1()


        Dim Nome As String
        Dim Sobrenome As String


        Sobrenome = "Almeida"
        Nome = "Eduarada"

        Dim ClaseUtil As New ClasseUtil()

        'ClaseUtil.nomeSobrenome(Nome, Sobrenome)

        ListBoxSegundaTela.Items.Add(ClaseUtil.nomeSobrenome())


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        ListBoxSegundaTela.Items.Remove(ListBoxSegundaTela.SelectedItem)

    End Sub
End Class