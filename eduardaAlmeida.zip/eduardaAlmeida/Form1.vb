﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim idade As Integer


        Dim classeUtil As New ClasseUtil()


        idade = TextBoxIdade.Text
        classeUtil.validadorIdade(idade)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim nome = TextBoxNome.Text

        ListBoxRegistros.Items.Add("Registro Add " & nome & " ," & TextBoxIdade.Text & " ," & TextBoxProfissao.Text)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim SegundaTela As New SegundaTela()
        SegundaTela.ShowDialog()

    End Sub
End Class
